package com.example.map_exam

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
